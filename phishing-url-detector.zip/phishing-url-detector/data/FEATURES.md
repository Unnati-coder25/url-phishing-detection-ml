# Dataset & Feature Description

**File:** `data/urls_dataset.csv` — columns `url`, `label` (1 = phishing, 0 = legitimate).

> The bundled file is a **synthetic demo dataset** produced by `src/generate_data.py` (~11k URLs, 2% label noise) so the repo runs offline.
> For real results, replace it with a public dataset that has the same two columns:
> - PhiUSIIL Phishing URL Dataset (UCI Machine Learning Repository)
> - "Phishing Site URLs" / "Malicious URLs" datasets on Kaggle
> - PhishTank / OpenPhish feeds (phishing) + Tranco top-sites list (legitimate)
>
> Then run `python -m src.train`. Report the accuracy you actually obtain on the real data.

## The 35 features (`src/features.py`)
| Group | Features |
|---|---|
| Length | url_length, hostname_length, path_length, query_length |
| Character counts | num_dots, num_hyphens, num_underscores, num_slashes, num_digits, num_letters, num_special_chars, digit_ratio, uppercase_ratio |
| Host / domain | has_ip_address, num_subdomains, tld_length, suspicious_tld, has_port, host_digit_count, host_hyphen_count, has_punycode, is_shortener, host_entropy |
| Suspicious patterns | has_at_symbol, double_slash_in_path, has_hex_encoding, uses_https, has_executable_ext |
| Semantic | keyword_count (login, verify, secure…), brand_in_subdomain_or_path |
| Structure / entropy | num_query_params, path_depth, url_entropy, longest_token_length, avg_token_length |
