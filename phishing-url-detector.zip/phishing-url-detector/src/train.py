"""Train XGBoost (+ baselines), evaluate, save model, metrics and plots."""
import json, time, joblib, numpy as np, pandas as pd, matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from xgboost import XGBClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score, roc_auc_score,
    roc_curve, confusion_matrix, ConfusionMatrixDisplay, classification_report)
from sklearn.model_selection import cross_val_score
from src.preprocess import load_and_prepare
from src.features import FEATURE_NAMES, extract_features

(X_tr, X_te, y_tr, y_te), _ = load_and_prepare()
PARAMS = dict(n_estimators=300, max_depth=6, learning_rate=0.1, subsample=0.8, colsample_bytree=0.8,
              eval_metric="logloss", random_state=42, n_jobs=-1)
xgb = XGBClassifier(**PARAMS).fit(X_tr, y_tr)
mu, sd = X_tr.mean(), X_tr.std().replace(0, 1)
models = {"Logistic Regression": LogisticRegression(max_iter=2000).fit((X_tr-mu)/sd, y_tr),
          "Random Forest": RandomForestClassifier(200, random_state=42, n_jobs=-1).fit(X_tr, y_tr), "XGBoost": xgb}
acc = {n: accuracy_score(y_te, m.predict((X_te-mu)/sd if n=="Logistic Regression" else X_te)) for n, m in models.items()}

pred = xgb.predict(X_te); proba = xgb.predict_proba(X_te)[:,1]
cv = cross_val_score(XGBClassifier(**PARAMS), X_tr, y_tr, cv=5, scoring="accuracy")
sample = "http://paypal.secure-login.xyz/verify?id=123"; ts=[]
for _ in range(200):   # end-to-end single-URL latency: feature extraction + prediction
    t=time.perf_counter(); xgb.predict_proba(pd.DataFrame([extract_features(sample)])[FEATURE_NAMES]); ts.append((time.perf_counter()-t)*1000)
metrics = {"accuracy":accuracy_score(y_te,pred),"precision":precision_score(y_te,pred),"recall":recall_score(y_te,pred),
  "f1":f1_score(y_te,pred),"roc_auc":roc_auc_score(y_te,proba),"cv_accuracy_mean":cv.mean(),"cv_accuracy_std":cv.std(),
  "model_comparison_accuracy":acc,"inference_ms_mean":float(np.mean(ts)),"inference_ms_p95":float(np.percentile(ts,95)),
  "n_features":len(FEATURE_NAMES),"n_train":len(y_tr),"n_test":len(y_te)}
json.dump(metrics, open("results/metrics.json","w"), indent=2)
json.dump(PARAMS, open("models/model_config.json","w"), indent=2)
open("results/classification_report.txt","w").write(classification_report(y_te,pred,target_names=["Legitimate","Phishing"]))
joblib.dump(xgb, "models/xgboost_phishing_model.joblib")

ConfusionMatrixDisplay(confusion_matrix(y_te,pred), display_labels=["Legitimate","Phishing"]).plot(cmap="Blues")
plt.title("Confusion Matrix - XGBoost"); plt.savefig("results/confusion_matrix.png",dpi=150,bbox_inches="tight"); plt.close()
fpr,tpr,_ = roc_curve(y_te,proba); plt.plot(fpr,tpr,label=f"XGBoost (AUC={metrics['roc_auc']:.3f})"); plt.plot([0,1],[0,1],"--",c="gray")
plt.xlabel("False Positive Rate"); plt.ylabel("True Positive Rate"); plt.title("ROC Curve"); plt.legend(); plt.savefig("results/roc_curve.png",dpi=150,bbox_inches="tight"); plt.close()
plt.bar(acc.keys(), [v*100 for v in acc.values()], color=["#94a3b8","#60a5fa","#16a34a"]); plt.ylim(80,100); plt.ylabel("Accuracy (%)")
for i,v in enumerate(acc.values()): plt.text(i, v*100+.2, f"{v*100:.2f}%", ha="center")
plt.title("Model Accuracy Comparison"); plt.savefig("results/accuracy_comparison.png",dpi=150,bbox_inches="tight"); plt.close()
imp = sorted(zip(FEATURE_NAMES, xgb.feature_importances_), key=lambda x:x[1])[-15:]
plt.figure(figsize=(7,5)); plt.barh([a for a,_ in imp],[b for _,b in imp],color="#2563eb"); plt.title("Top 15 Feature Importances")
plt.savefig("results/feature_importance.png",dpi=150,bbox_inches="tight"); plt.close()
print(json.dumps(metrics, indent=2)); print(open("results/classification_report.txt").read())
