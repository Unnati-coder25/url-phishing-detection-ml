"""Data preprocessing: load CSV -> clean -> features -> train/test split."""
import pandas as pd
from sklearn.model_selection import train_test_split
from src.features import extract_features, FEATURE_NAMES

def load_and_prepare(path="data/urls_dataset.csv", test_size=0.2, seed=42):
    df = pd.read_csv(path).dropna(subset=["url","label"])
    df["url"] = df["url"].astype(str).str.strip()
    df = df[df.url.str.len() > 3].drop_duplicates("url")
    X = pd.DataFrame([extract_features(u) for u in df.url])[FEATURE_NAMES]
    y = df["label"].astype(int).values
    return train_test_split(X, y, test_size=test_size, stratify=y, random_state=seed), df
