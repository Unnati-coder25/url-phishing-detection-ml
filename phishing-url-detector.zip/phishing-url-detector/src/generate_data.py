"""Builds a SYNTHETIC demo dataset (no internet needed). Replace with a real dataset for production
(see README: PhiUSIIL / Kaggle / PhishTank + Tranco). Output CSV schema: url,label (1=phishing, 0=legit)."""
import random, string, pandas as pd
random.seed(42)
LEGIT = ["google.com","wikipedia.org","github.com","amazon.in","flipkart.com","microsoft.com","apple.com","bbc.co.uk","nytimes.com",
 "stackoverflow.com","linkedin.com","youtube.com","paypal.com","netflix.com","zomato.com","irctc.co.in","sbi.co.in","hdfcbank.com",
 "coursera.org","medium.com","reddit.com","npmjs.com","python.org","w3schools.com","khanacademy.org","ndtv.com","hotstar.com","swiggy.com"]
WORDS = ["news","shop","blog","docs","product","category","article","item","help","about","contact","jobs","pricing","learn","watch","search","profile","settings","orders","support","login","account"]
SUBS = ["www","mail","docs","accounts","blog","shop","support","m","api"]
BRANDS = ["paypal","apple","amazon","microsoft","netflix","google","facebook","chase","dhl","sbi","hdfc","icici"]
TLDS = ["xyz","top","tk","ml","click","link","work","buzz","info","online","site","com","net"]
KW = ["login","verify","secure","update","account","confirm","signin","banking","wallet","unlock","billing"]
rnd = lambda n: "".join(random.choices(string.ascii_lowercase+string.digits, k=n))
word = lambda: random.choice(WORDS)

def legit():
    d = random.choice(LEGIT); s = random.choice(SUBS+[""]*3)
    host = (s+"." if s else "")+d
    path = "/"+"/".join(word()+(f"-{random.randint(1,999)}" if random.random()<.4 else "") for _ in range(random.randint(0,3)))
    q = f"?id={random.randint(1,99999)}&ref={word()}" if random.random()<.3 else ""
    return random.choice(["https","https","https","http"])+"://"+host+path+q

def phish():
    t = random.random(); b = random.choice(BRANDS); k = random.choice(KW); tld = random.choice(TLDS)
    if t<.18: return f"http://{random.randint(11,223)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(1,254)}/{k}/{rnd(6)}.php"
    if t<.40: return f"http://{b}.{k}.{rnd(random.randint(5,10))}.{tld}/{k}?session={rnd(16)}"
    if t<.55: return f"https://{b}-{k}-{rnd(4)}.{tld}/{word()}/{k}.html"
    if t<.65: return f"http://{b}.com@{rnd(8)}.{tld}/{k}"
    if t<.75: return f"https://{random.choice(['bit.ly','tinyurl.com','cutt.ly'])}/{rnd(7)}"
    if t<.85: return f"https://{rnd(random.randint(6,12))}.{tld}/{k}/{b}/index.php?id={rnd(20)}&token={rnd(24)}"
    if t<.93: return f"http://{rnd(6)}.{tld}:8080/{rnd(5)}/{k}%2F{rnd(4)}.exe"
    return f"https://{rnd(7)}.com/{word()}"   # hard, near-legit-looking phishing

rows = [(legit(),0) for _ in range(6000)] + [(phish(),1) for _ in range(6000)]
rows = [(u.replace("/login","/account/login") if l==0 and random.random()<.1 else u, l) for u,l in rows]
rows = [(u, 1-l if random.random()<.02 else l) for u,l in rows]      # 2% label noise
df = pd.DataFrame(rows, columns=["url","label"]).drop_duplicates("url").sample(frac=1, random_state=42)
df.to_csv("data/urls_dataset.csv", index=False); print(df.label.value_counts(), len(df))
