"""Prediction / detection module."""
import sys, time, joblib, pandas as pd
from src.features import extract_features, FEATURE_NAMES
_MODEL = None
def get_model(path="models/xgboost_phishing_model.joblib"):
    global _MODEL
    if _MODEL is None: _MODEL = joblib.load(path)
    return _MODEL
def predict_url(url: str) -> dict:
    t = time.perf_counter()
    X = pd.DataFrame([extract_features(url)])[FEATURE_NAMES]
    p = float(get_model().predict_proba(X)[0][1])
    return {"url": url, "prediction": "phishing" if p >= 0.5 else "legitimate",
            "phishing_probability": round(p, 4), "inference_ms": round((time.perf_counter()-t)*1000, 2)}
if __name__ == "__main__":
    for u in sys.argv[1:] or ["https://www.google.com/search?q=python", "http://paypal.secure-login.xyz/verify?id=123"]:
        print(predict_url(u))
