"""URL / domain feature extraction (35 features)."""
import math, re
from collections import Counter
from urllib.parse import urlparse

SUSPICIOUS_TLDS = {"xyz","top","tk","ml","ga","cf","gq","click","link","work","loan","zip","country","support","monster","buzz","rest"}
SHORTENERS = {"bit.ly","tinyurl.com","goo.gl","t.co","ow.ly","is.gd","buff.ly","rebrand.ly","cutt.ly"}
KEYWORDS = ["login","signin","verify","update","secure","account","banking","confirm","password","wallet","support","billing","suspend","unlock","free","bonus","invoice","paypal","apple","amazon","microsoft","netflix"]
BRANDS = ["paypal","apple","amazon","microsoft","netflix","google","facebook","instagram","chase","dhl","fedex","sbi","hdfc","icici"]
IP_RE = re.compile(r"^(?:\d{1,3}\.){3}\d{1,3}$")

def _entropy(s):
    if not s: return 0.0
    n = len(s)
    return -sum(c/n*math.log2(c/n) for c in Counter(s).values())

def _split(url):
    if not re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*://", url):
        url = "http://" + url
    p = urlparse(url)
    host = (p.hostname or "").lower()
    return url, p, host

FEATURE_NAMES = [
 "url_length","hostname_length","path_length","query_length","num_dots","num_hyphens","num_underscores",
 "num_slashes","num_digits","num_letters","digit_ratio","num_special_chars","has_at_symbol","has_ip_address",
 "uses_https","num_subdomains","tld_length","suspicious_tld","num_query_params","has_port","double_slash_in_path",
 "has_hex_encoding","keyword_count","brand_in_subdomain_or_path","is_shortener","url_entropy","host_entropy",
 "longest_token_length","avg_token_length","host_digit_count","host_hyphen_count","path_depth","has_punycode",
 "uppercase_ratio","has_executable_ext",
]

def extract_features(url: str) -> dict:
    url = url.strip()
    full, p, host = _split(url)
    path, query = p.path or "", p.query or ""
    parts = host.split(".") if host else []
    tld = parts[-1] if len(parts) > 1 else ""
    sub = parts[:-2]
    low = url.lower()
    tokens = [t for t in re.split(r"[^a-zA-Z0-9]+", low) if t]
    letters = sum(c.isalpha() for c in url); digits = sum(c.isdigit() for c in url)
    n = max(len(url), 1)
    main = parts[-2] if len(parts) >= 2 else host
    brand_hit = any(b in ".".join(sub) + path.lower() for b in BRANDS) and not any(b == main for b in BRANDS)
    try: port = p.port
    except ValueError: port = None
    f = {
     "url_length": len(url), "hostname_length": len(host), "path_length": len(path), "query_length": len(query),
     "num_dots": url.count("."), "num_hyphens": url.count("-"), "num_underscores": url.count("_"),
     "num_slashes": url.count("/"), "num_digits": digits, "num_letters": letters, "digit_ratio": digits/n,
     "num_special_chars": sum(not c.isalnum() for c in url), "has_at_symbol": int("@" in url),
     "has_ip_address": int(bool(IP_RE.match(host))), "uses_https": int(p.scheme == "https"),
     "num_subdomains": max(len(sub), 0), "tld_length": len(tld), "suspicious_tld": int(tld in SUSPICIOUS_TLDS),
     "num_query_params": len([q for q in query.split("&") if q]), "has_port": int(port is not None),
     "double_slash_in_path": int("//" in path), "has_hex_encoding": int("%" in url),
     "keyword_count": sum(k in low for k in KEYWORDS), "brand_in_subdomain_or_path": int(brand_hit),
     "is_shortener": int(host in SHORTENERS), "url_entropy": _entropy(url), "host_entropy": _entropy(host),
     "longest_token_length": max((len(t) for t in tokens), default=0),
     "avg_token_length": sum(map(len, tokens))/len(tokens) if tokens else 0,
     "host_digit_count": sum(c.isdigit() for c in host), "host_hyphen_count": host.count("-"),
     "path_depth": len([s for s in path.split("/") if s]), "has_punycode": int("xn--" in host),
     "uppercase_ratio": sum(c.isupper() for c in url)/n,
     "has_executable_ext": int(bool(re.search(r"\.(exe|apk|scr|zip|bat|msi)(\?|$)", path.lower()))),
    }
    return {k: f[k] for k in FEATURE_NAMES}
