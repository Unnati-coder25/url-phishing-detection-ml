# AI Phishing & Malicious URL Detection
Python · XGBoost · Scikit-learn · Flask · REST API

Detects phishing / malicious URLs using **35 engineered URL & domain features** and an **XGBoost** classifier, served through a **Flask REST API** (plus a small web UI).

![architecture](docs/architecture_diagram.png)

## Results (held-out 20% test set, 2262 URLs)
| Metric | Value |
|---|---|
| Accuracy | 97.57% |
| Precision / Recall / F1 | 97.50% / 97.91% / 97.71% |
| ROC-AUC | 0.9771 |
| 5-fold CV accuracy | 97.59% ± 0.26% |
| Inference (features + predict, single URL) | 3.2 ms mean, 4.6 ms p95 |
| API round-trip over localhost (300 requests) | 4.99 ms mean, 6.76 ms p95 |

> **Note:** the bundled dataset is synthetic (see `data/FEATURES.md`). Re-train on a real dataset and update these numbers before quoting them.

Graphs: `results/confusion_matrix.png`, `roc_curve.png`, `accuracy_comparison.png`, `feature_importance.png`; text: `results/classification_report.txt`, `metrics.json`.

## Project structure
```
app.py                  Flask REST API + UI
src/features.py         URL feature extraction
src/preprocess.py       cleaning + split
src/train.py            training, evaluation, plots, model export
src/predict.py          prediction logic
src/generate_data.py    synthetic demo dataset builder
notebooks/              end-to-end Jupyter notebook
models/                 xgboost_phishing_model.joblib, model_config.json
tests/test_api.py       API tests
templates/index.html    web UI
```

## Installation
```bash
git clone <your-repo-url> && cd phishing-url-detector
python -m venv venv && source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## Execution
```bash
python src/generate_data.py     # (optional) rebuild demo dataset
python -m src.train             # train + save model + graphs
python -m src.predict "http://paypal.secure-login.xyz/verify"
python app.py                   # http://127.0.0.1:5000
pytest -q tests                 # run API tests
```

## API usage
```bash
curl -X POST http://127.0.0.1:5000/predict -H "Content-Type: application/json" \
     -d '{"url": "http://paypal.secure-login.xyz/verify?id=123"}'
```
```json
{"inference_ms": 5.2, "phishing_probability": 0.6143, "prediction": "phishing", "url": "http://paypal.secure-login.xyz/verify?id=123"}
```
| Endpoint | Method | Body |
|---|---|---|
| `/health` | GET | – |
| `/predict` | POST | `{"url": "..."}` |
| `/predict_batch` | POST | `{"urls": ["...", "..."]}` (max 100) |

Errors return HTTP 400 with a JSON message.

## Screenshots
Located in `screenshots/` (Flask UI, phishing + legitimate detection, API responses, test results, `demo.gif`).

## Limitations
URL-only lexical features (no page content / WHOIS / reputation); can be evaded by clean-looking domains. Use as one signal in a layered defence.
