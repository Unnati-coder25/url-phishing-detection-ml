"""API tests (Flask test client). Run: pytest -q"""
from app import app
c = app.test_client()
def test_health(): assert c.get("/health").json["status"] == "ok"
def test_phishing():
    r = c.post("/predict", json={"url": "http://paypal.secure-login.xyz/verify?id=123"}); assert r.json["prediction"] == "phishing"
def test_legit():
    r = c.post("/predict", json={"url": "https://www.github.com/docs"}); assert r.json["prediction"] == "legitimate"
def test_bad_input(): assert c.post("/predict", json={}).status_code == 400
def test_batch():
    r = c.post("/predict_batch", json={"urls": ["https://www.google.com", "http://185.23.4.9/login/a.php"]}); assert len(r.json["results"]) == 2
