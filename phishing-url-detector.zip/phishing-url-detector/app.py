"""Flask REST API + web UI for phishing URL detection."""
from flask import Flask, request, jsonify, render_template
from src.predict import predict_url, get_model
app = Flask(__name__); get_model()   # load model once at startup (keeps latency low)

@app.get("/")
def index():
    url = request.args.get("url")
    return render_template("index.html", prefill=url, res=predict_url(url) if url else None)

@app.get("/health")
def health(): return jsonify(status="ok")

@app.post("/predict")
def predict():
    url = (request.get_json(silent=True) or {}).get("url", "")
    if not isinstance(url, str) or len(url.strip()) < 4 or len(url) > 2048:
        return jsonify(error="Provide JSON body: {\"url\": \"<url up to 2048 chars>\"}"), 400
    return jsonify(predict_url(url))

@app.post("/predict_batch")
def predict_batch():
    urls = (request.get_json(silent=True) or {}).get("urls", [])
    if not isinstance(urls, list) or not urls or len(urls) > 100:
        return jsonify(error="Provide {\"urls\": [..up to 100..]}"), 400
    return jsonify(results=[predict_url(u) for u in urls if isinstance(u, str)])

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
