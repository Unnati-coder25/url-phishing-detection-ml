"""Generates API screenshots (rendered from LIVE responses), architecture diagram and demo GIF. Requires running server + wkhtmltoimage."""
import requests, json, html, subprocess
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from PIL import Image
def card(method, path, body, resp, status, ms, out):
    r = lambda s: html.escape(json.dumps(s, indent=2))
    h = f"""<html><body style="font-family:Consolas,monospace;background:#fff;padding:20px;width:780px">
<div style="background:#f26522;color:#fff;padding:8px 14px;font-weight:bold">API client view (Postman-equivalent) - real response from running Flask server</div>
<div style="border:1px solid #ddd;padding:10px"><b style="color:#0a7d33">{method}</b> http://127.0.0.1:5000{path}</div>
<div style="border:1px solid #ddd;border-top:0;padding:10px"><b>Body (raw JSON)</b><pre style="background:#f6f6f6;padding:8px">{r(body)}</pre></div>
<div style="border:1px solid #ddd;border-top:0;padding:10px"><b>Response</b> &nbsp; <span style="color:#0a7d33">Status: {status}</span> &nbsp; Time: {ms} ms
<pre style="background:#f6f6f6;padding:8px">{r(resp)}</pre></div></body></html>"""
    open("/tmp/c.html","w").write(h); subprocess.run(["wkhtmltoimage","--quiet","--width","820","/tmp/c.html",out],stderr=subprocess.DEVNULL)
S="http://127.0.0.1:5000"
for n,u in [("phishing","http://paypal.secure-login.xyz/verify?id=123"),("legit","https://www.github.com/docs")]:
    rr=requests.post(S+"/predict",json={"url":u}); card("POST","/predict",{"url":u},rr.json(),rr.status_code,round(rr.elapsed.total_seconds()*1000,1),f"screenshots/postman_{n}_response.png")
b=["https://www.google.com/search?q=python","http://185.23.4.9/login/verify.php","https://www.wikipedia.org/docs/help"]
rr=requests.post(S+"/predict_batch",json={"urls":b}); card("POST","/predict_batch",{"urls":b},rr.json(),rr.status_code,round(rr.elapsed.total_seconds()*1000,1),"screenshots/postman_batch_response.png")
rr=requests.post(S+"/predict",json={}); card("POST","/predict",{},rr.json(),rr.status_code,round(rr.elapsed.total_seconds()*1000,1),"screenshots/postman_error_handling.png")
txt=open("results/pytest_output.txt").read()+"\n"+json.dumps(json.load(open("results/api_latency.json")),indent=2)+"\n\n(300 sequential HTTP POST /predict calls, localhost)"
open("/tmp/t.html","w").write(f"<html><body style='background:#111;color:#8f8;font-family:Consolas,monospace;padding:20px;width:700px'><pre>$ pytest -q tests\n{html.escape(txt)}</pre></body></html>")
subprocess.run(["wkhtmltoimage","--quiet","--width","740","/tmp/t.html","screenshots/api_test_results_and_latency.png"],stderr=subprocess.DEVNULL)
fig,ax=plt.subplots(figsize=(13,4.2)); ax.axis("off"); ax.set_xlim(0,13); ax.set_ylim(0,4.2)
boxes=[("URL dataset\n(url,label)",.2),("Preprocessing\nclean + dedupe\nstratified split",2.2),("Feature extraction\n35 URL/domain\nfeatures",4.2),("XGBoost training\n+ evaluation\n(.joblib saved)",6.2),("Flask REST API\n/predict\n/predict_batch",8.4),("Client\nWeb UI / Postman\n/ curl",10.7)]
for t,x in boxes:
    ax.add_patch(FancyBboxPatch((x,1.4),1.9,1.5,boxstyle="round,pad=0.05",fc="#dbeafe",ec="#2563eb",lw=1.5)); ax.text(x+.95,2.15,t,ha="center",va="center",fontsize=9.5)
for x in [2.15,4.15,6.15,8.35,10.65]: ax.annotate("",xy=(x+.1,2.15),xytext=(x-.2,2.15),arrowprops=dict(arrowstyle="->",lw=2,color="#1e3a8a"))
ax.text(4.1,3.8,"Training pipeline (offline)",ha="center",fontsize=11,weight="bold",color="#1e3a8a"); ax.plot([.2,8.1],[3.45,3.45],c="#1e3a8a")
ax.text(10.5,3.8,"Inference (online)",ha="center",fontsize=11,weight="bold",color="#166534"); ax.plot([8.4,12.6],[3.45,3.45],c="#166534")
ax.text(6.5,.7,'Request {"url": ...}  ->  extract features  ->  model.predict_proba  ->  {"prediction", "phishing_probability", "inference_ms"}',ha="center",fontsize=9.5,style="italic")
plt.savefig("docs/architecture_diagram.png",dpi=150,bbox_inches="tight"); plt.close()
fr=[Image.open(f"screenshots/{n}.png").convert("P").resize((760,330)) for n in ["flask_app_home","flask_phishing_detection","flask_legit_detection"]]
fr[0].save("screenshots/demo.gif",save_all=True,append_images=fr[1:],duration=1800,loop=0)
