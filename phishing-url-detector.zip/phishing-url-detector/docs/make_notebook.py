import nbformat as nbf
nb = nbf.v4.new_notebook(); C=nbf.v4.new_code_cell; M=nbf.v4.new_markdown_cell
nb.cells = [
M("# AI Phishing & Malicious URL Detection\nPython · XGBoost · Scikit-learn · Flask REST API\n\nRun from the `notebooks/` folder (paths are relative to the project root)."),
C("import os; os.chdir('..') if os.path.basename(os.getcwd())=='notebooks' else None\nimport sys; sys.path.insert(0, '.')\nimport pandas as pd, numpy as np, matplotlib.pyplot as plt\nfrom src.features import extract_features, FEATURE_NAMES\nprint(len(FEATURE_NAMES), 'features')"),
M("## 1. Load dataset"),
C("df = pd.read_csv('data/urls_dataset.csv'); print(df.shape); print(df.label.value_counts()); df.sample(5, random_state=1)"),
M("## 2. Feature extraction (35 URL/domain features)"),
C("pd.DataFrame([extract_features('http://paypal.secure-login.xyz/verify?id=123')]).T.rename(columns={0:'value'})"),
M("## 3. Preprocess + split"),
C("from src.preprocess import load_and_prepare\n(X_tr, X_te, y_tr, y_te), clean = load_and_prepare()\nprint(X_tr.shape, X_te.shape)"),
M("## 4. Train XGBoost and compare with baselines"),
C("from xgboost import XGBClassifier\nfrom sklearn.ensemble import RandomForestClassifier\nfrom sklearn.linear_model import LogisticRegression\nfrom sklearn.metrics import accuracy_score\nxgb = XGBClassifier(n_estimators=300, max_depth=6, learning_rate=0.1, subsample=0.8, colsample_bytree=0.8, eval_metric='logloss', random_state=42).fit(X_tr, y_tr)\nrf = RandomForestClassifier(200, random_state=42).fit(X_tr, y_tr)\nmu, sd = X_tr.mean(), X_tr.std().replace(0,1)\nlr = LogisticRegression(max_iter=2000).fit((X_tr-mu)/sd, y_tr)\nprint('XGBoost', accuracy_score(y_te, xgb.predict(X_te)))\nprint('RandomForest', accuracy_score(y_te, rf.predict(X_te)))\nprint('LogReg', accuracy_score(y_te, lr.predict((X_te-mu)/sd)))"),
M("## 5. Evaluation"),
C("from sklearn.metrics import classification_report, ConfusionMatrixDisplay, RocCurveDisplay\nprint(classification_report(y_te, xgb.predict(X_te), target_names=['Legitimate','Phishing']))\nConfusionMatrixDisplay.from_estimator(xgb, X_te, y_te, cmap='Blues'); plt.show()\nRocCurveDisplay.from_estimator(xgb, X_te, y_te); plt.show()"),
M("## 6. Feature importance"),
C("imp = pd.Series(xgb.feature_importances_, index=FEATURE_NAMES).sort_values().tail(15); imp.plot.barh(figsize=(7,5)); plt.title('Top 15 features'); plt.show()"),
M("## 7. Predictions + inference time"),
C("import joblib; os.makedirs('models', exist_ok=True)\nfrom src.predict import predict_url\nfor u in ['https://www.github.com/docs','http://paypal.secure-login.xyz/verify?id=123','http://185.23.4.9/login/verify.php']:\n    print(predict_url(u))"),
M("The full pipeline (also saves the model + plots) is in `src/train.py`; the REST API is in `app.py`."),
]
nbf.write(nb, "notebooks/phishing_url_detection.ipynb")
